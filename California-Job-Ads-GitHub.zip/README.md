# Advertised benefits in California job ads

Job seekers comparing ads with similar hourly pay often have to piece together benefit details from structured lists and descriptions. This YIC Datathon project asks whether part-time and full-time California Indeed ads disclose similar benefits at similar hourly pay. The public dashboard helps job seekers and workforce advisers compare disclosures and identify questions about coverage and eligibility.

Across **39,161 comparable ads**, the wage-adjusted mean benefit score was **1.670 for full-time** and **0.958 for part-time**. Part-time ads listed **0.712 fewer categories** on average. Including qualifying description mentions gave a gap of **0.709 fewer categories**.

- [Live Tableau dashboard](https://public.tableau.com/app/profile/celine.tan7285/viz/YIC_Datathon2026/Dashboard)
- [Project presentation](docs/California_Job_Ads.pptx)
- [Analysis notebook](Datathon2026.ipynb)
- [Methodology and limitations](docs/methodology.md)
- [Findings and Tableau demo](docs/findings.md)
- [Aggregate wage-band results](results/wage_band_summary.csv)

## Reproduce the analysis

1. From the repository root, create a Python 3.11 virtual environment and install the dependencies.

   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   python -m pip install -r requirements.txt
   ```

   On Windows PowerShell, activate with `.venv\Scripts\Activate.ps1`.

2. Obtain an authorized copy of the datathon's Indeed dataset and place it at `indeed_jobs.csv` in the repository root. The notebook uses `jobid`, `job_title`, `job_type`, `salary_formatted`, `benefits`, and `description_text`. The original CSV was approximately 2.15 GB and is loaded into memory by pandas.

3. Run `python -m jupyterlab` from the repository root. Open `Datathon2026.ipynb` and run all cells in order with the virtual environment's Python kernel. The notebook recreates the review template if absent and reuses decisions in an existing `benefit_additions_review.csv`. For exact replication of the original review state, use the original review CSV if available. It contains posting-level text and is omitted from this package.

4. To rebuild the dashboard views in Tableau, connect to `tableau_dashboard.csv` and `tableau_occupation_benefits.csv` as text files. The [findings page](docs/findings.md) describes how the two views use these exports.

The aggregate CSV contains the saved structured-only wage-band means and counts from the submitted notebook. This package includes neither the raw data nor posting-level exports. Check the dataset's terms before distributing either. Use the live link to view the published dashboard.
