# Methodology

## Explore and screen the data

The notebook loaded 140,816 Indeed ads into pandas and inspected job types, pay formats, and benefit fields. It retained 93,937 ads with an exact full-time or part-time label. Single or closed-range hourly pay appeared in 33.4% of full-time ads and 79.5% of part-time ads before wage-quality screening.

The code retained 39,479 hourly candidates, using the midpoint of each closed range. It screened out 89 ads by requiring a valid rate and both endpoints from $10 inclusive to $300 exclusive. It then dropped 229 ads in wage bands with fewer than ten postings from either group. The final sample contains 25,293 full-time and 13,868 part-time ads across 19 $5 wage bands.

## Refine the score

Normalize the names listed in the structured benefits field and flag each of three categories once per ad. The flags cover medical insurance, explicitly paid leave, and retirement. Inspecting raw entries expanded the initial terms to include benefits such as unlimited paid time off, paid jury duty, 403(b) plans, and percentage-based 401(k) matches. A 401(k) and a match together earn one retirement point. Paid training and leave without explicit pay earn no paid-leave point. The three flags sum to a 0–3 count. Zero means the measured field contained no qualifying evidence.

## Check the description text

In the comparable sample, 1,543 ads had a missing structured benefits field. Descriptions can also disclose categories absent from a populated list. The notebook looks for mentions of missing categories and uses context rules and review decisions to flag clear offers, conditional language, and incidental mentions such as privacy wording. The combined score adds only candidates classified as advertised. The saved review output shows 1,188 unresolved candidates. The rules have yet to be validated on a fresh holdout sample.

## Compare within wage bands

Calculate group means within each qualifying band. Weight each band by its share of pooled comparable ads, using the same weights for part-time and full-time. The gap is part-time minus full-time. Applying the same weights to binary flags gives the wage-adjusted category percentages.

## Interpret the estimates

The analysis describes the selected Indeed postings with usable hourly pay. Employer and occupation mix can differ within wage bands. The title-based occupation groups are exploratory and leave many ads unclassified. The analysis provides no uncertainty intervals and does not estimate actual benefit eligibility or a causal effect.
