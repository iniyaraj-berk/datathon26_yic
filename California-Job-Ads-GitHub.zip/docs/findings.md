# Findings and Tableau demo

| Wage-adjusted score | Full-time | Part-time | Gap (part-time minus full-time) |
| --- | ---: | ---: | ---: |
| Structured only | 1.670 | 0.958 | −0.712 |
| Structured + text | 1.673 | 0.964 | −0.709 |

| Advertised benefit, structured only | Full-time | Part-time | Gap (percentage points) |
| --- | ---: | ---: | ---: |
| Medical insurance | 60.4% | 32.0% | −28.4 |
| Paid leave | 52.1% | 29.3% | −22.8 |
| Retirement | 54.5% | 34.5% | −19.9 |

Rates and gaps are rounded separately. Part-time ads had lower structured scores in 18 of 19 qualifying bands. The $90 to under $95 band reversed the pattern and had 106 ads.

## Demo

Open the [public Tableau dashboard](https://public.tableau.com/app/profile/celine.tan7285/viz/YIC_Datathon2026/Dashboard).

1. In the wage view, hover over the $20 band marks. Each mark shows a mean benefit score and the posting count. To recreate this view, use `tableau_dashboard.csv` with wage band, mean benefit count, job type, postings, and method.
2. Switch **Benefit Measurement** between **Structured only** and **Structured + text**. Show one method at a time.
3. In the occupation view, select **Retail and sales** and isolate medical insurance with **Benefit Category**. The occupation view uses `tableau_occupation_benefits.csv` and plots averages of the benefit flags as unadjusted percentages. The occupation filter applies to that view.

## Social good

A job seeker comparing two $22/hour offers can check what similar ads typically disclose, then ask whether medical insurance is offered and how many weekly hours are required to qualify. Workforce advisers can use the dashboard to guide those conversations. The project measures disclosures and has not evaluated downstream impact on job seekers.
